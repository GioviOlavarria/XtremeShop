package com.example.miapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiappApplicationTests {

	@Test
	void contextLoads() {
	}

}
